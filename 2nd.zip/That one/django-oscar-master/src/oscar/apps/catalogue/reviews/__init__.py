default_app_config = "oscar.apps.catalogue.reviews.apps.CatalogueReviewsConfig"
