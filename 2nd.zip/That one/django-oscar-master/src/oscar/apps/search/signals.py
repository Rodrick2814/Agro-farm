from django.dispatch import Signal

user_search = Signal()
