default_app_config = "oscar.apps.wishlists.apps.WishlistsConfig"
