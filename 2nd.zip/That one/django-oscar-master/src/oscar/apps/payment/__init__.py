default_app_config = "oscar.apps.payment.apps.PaymentConfig"
