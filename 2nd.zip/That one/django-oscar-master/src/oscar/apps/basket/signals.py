import django.dispatch

basket_addition = django.dispatch.Signal()
voucher_addition = django.dispatch.Signal()
voucher_removal = django.dispatch.Signal()
