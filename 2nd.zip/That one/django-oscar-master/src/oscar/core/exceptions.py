# -*- coding: utf-8 -*-


# pylint: disable=W0622
class ModuleNotFoundError(Exception):
    pass


class AppNotFoundError(Exception):
    pass


class ClassNotFoundError(Exception):
    pass
