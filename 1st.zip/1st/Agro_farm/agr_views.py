from django.shortcuts import render, redirect
from .forms import TransactionForm
from .models import Transaction

def deposit_view(request):
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.user = request.user
            transaction.save()
            return redirect('transaction_history')  # Redirect to transaction history page
    else:
        form = TransactionForm()
    return render(request, 'deposit.html', {'form': form})

def withdraw_view(request):
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.user = request.user
            transaction.amount = -transaction.amount  # Withdrawal amount is negative
            transaction.save()
            return redirect('transaction_history')  # Redirect to transaction history page
    else:
        form = TransactionForm()
    return render(request, 'withdraw.html', {'form': form})