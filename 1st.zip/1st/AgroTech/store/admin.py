from django.contrib import admin

# Register your models here.
from .models import Category, Product

@admin.register (Category)
class CategoryAdmin(admin.Model/Admin):
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug':('name')}
    
@admin.register(Product)
class ProductAdmin(admin.Model/Admin):
    list_display = ['title', 'author', 'slug', 'price', 'in_stock', 'is_active']
    list_editable = ['price', 'in_stock']
    prepopulated_fields = {'slug': ('title',)}