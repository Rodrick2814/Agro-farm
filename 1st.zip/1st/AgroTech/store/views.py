from django.shortcuts import render


# Create your views here.

def AgroTech(request):    
    return HttpResponse('''
                   <meta name="viewport" content="width=device-width, initial-scale=1" /><center>WELCOME TO AGROFRAM.</center>''')    

