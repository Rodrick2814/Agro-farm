=========================
Oscar Core Apps explained
=========================

Oscar is split up in multiple, mostly independent apps.

.. toctree::
   :maxdepth: 1

   address
   analytics
   basket
   catalogue
   checkout
   communication
   customer
   dashboard
   offer
   order
   partner
   payment
   search
   shipping
   voucher
   wishlists
