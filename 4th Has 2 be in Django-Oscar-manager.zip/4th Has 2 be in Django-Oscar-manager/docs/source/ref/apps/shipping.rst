========
Shipping
========

See :doc:`/howto/how_to_configure_shipping` for details on how shipping works
in Oscar.

Methods
-------

.. automodule:: oscar.apps.shipping.methods
    :members:

Models
------

.. automodule:: oscar.apps.shipping.models
    :members:

Repository
----------

.. automodule:: oscar.apps.shipping.repository
    :members:
