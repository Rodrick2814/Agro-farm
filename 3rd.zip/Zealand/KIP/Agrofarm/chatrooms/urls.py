from django.urls import path
from . import views

urlpatterns = [
    path('', views.room, name='home'),
    path('<str:slug>/', views.chatroom)
    
]