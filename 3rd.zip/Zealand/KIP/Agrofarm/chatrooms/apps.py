from django.apps import AppConfig


class ChatroomsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatrooms'
