from django.shortcuts import render
from .models import Room, Message

# Create your views here.
def room(request):
    rooms = Room.objects.all()
    return render(request, "home.html",{
        "room": rooms
    })


def chatroom(request,slug):
    messages = Message.objects.filter(room=Room.objects.get(slug=slug))
    room_name = Room.objects.get(slug=slug).name
    context= {"slug": slug, "room_name":room_name,"messages":messages}
    return render(request, 'room.html', context)