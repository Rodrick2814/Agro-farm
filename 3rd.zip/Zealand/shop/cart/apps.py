from django.apps import AppConfig


class CartConfig(AppConfig):
    name: str = 'cart'
