from django.shortcuts import render
from django.http import HttpResponse
from .models import *

def index(request):
    content = Post.objects.all()
    context = {'content': content}
    return render(request, 'todo/index.html', context)
    
def home(request):    
    return HttpResponse('''
                   <meta name="viewport" content="width=device-width, initial-scale=1" /><center>WELCOME TO AGROFRAM.</center>''')    
# Create your views here.
def deposit(request):  
   # getting our template  
   return HttpResponse('''<DOCTYPE html>
    <html>
        <head>
               <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>DEPOSIT MONEY</title>
        <style>
            #number_input{
                border: 2px solid green;
            }
            #Depo{
                background-color: green;
            }
            input{
                border-radius: 10px;
            }
              header {
    background: #333;
    color: #fff;
    padding: 5px;
}

            nav ul {
    list-style: none;
}

nav ul li {
    display: inline;
    margin-right: 20px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}
                #image_menu{
                    height,width:30px ;
                }
        </style>
        </head>
        <body>
                        <header>
                    <nav>
            <ul>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agro_farm/transaction.html"><img src="content://ru.zdevs.zarchiver.external/storage/emulated/0/XXXAVIER%20/Box/food/Agrohub/menu.jpg" id='image_menu'/></a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/deposit.html">Deposit</a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/withdraw+.html">Withdraw</a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/send.html">Send</a></li>
            </ul>
        </nav>

        </header>
            <center>
                <h3><label>Enter amount to deposit</label></h3></h3><br>
                <input type=<input type="number" name="number_input" id="number_input" value="" /><br><br>
                <input type="submit" id="Depo"onclick="Tee()"/>
            </center>
        <script>
            function Tee(){
                var amount=document.getElementById('number_input').value;
                   if (amount != null) {
                        alert("Amount UGX " + amount + " successfully deposited onto your account");
                   }
            }
        </script>
        </body>
    </html>''')      
    # rendering the template in HttpResponse 
def withdraw(request):  
 # getting our template  
   return HttpResponse("""<DOCTYPE html>
    <html>
        <head>
               <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>WITHDRAW MONEY</title>
        <style>
            #number_input{
                border: 2px solid green;
            }
            #Depo{
                background-color: green;
            }
            input{
                border-radius: 10px;
            }
              header {
    background: #333;
    color: #fff;
    padding: 5px;
}

            nav ul {
    list-style: none;
}

nav ul li {
    display: inline;
    margin-right: 20px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}
                #image_menu{
                    height,width:30px ;
                }
        </style>
        </head>
        <body>
                        <header>
                    <nav>
            <ul>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agro_farm/transaction.html"><img src="content://ru.zdevs.zarchiver.external/storage/emulated/0/XXXAVIER%20/Box/food/Agrohub/menu.jpg" id='image_menu'/></a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agro_farm/deposit.html">Deposit</a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/withdraw+.html">Withdraw</a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/send.html">Send</a></li>
            </ul>
        </nav>
        </header>
            <center>
                <h3><label>Enter amount to withdraw</label></h3></h3><br>
                <input type=<input type="number" name="number_input" id="number_input" value="" /><br><br>
                <input type="submit" id="Depo" onclick="Tee()"/>
            </center>
        <script>
            function Tee(){
                var amount=document.getElementById('number_input').value;
                   if (amount != null) {
                        alert("Amount UGX " + amount + " successfully withdrawn from your account");
                   }
            }
        </script>
        </body>
    </html>""")       # rendering the template in HttpResponse
def send(request):  # getting our template  
   return HttpResponse('''<DOCTYPE html>
    <html>
        <head>
               <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>SEND MONEY</title>
        <style>
            #number_input,#amount{
                border: 2px solid green;
            }
            #Depo{
                background-color: green;
            }
            input{
                border-radius: 10px;
            }
              header {
    background: #333;
    color: #fff;
    padding: 5px;
}

            nav ul {
    list-style: none;
}

nav ul li {
    display: inline;
    margin-right: 20px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}
                #image_menu{
                    height,width:30px ;
                }
        </style>
        </head>
        <body>
                        <header>
                    <nav>
            <ul>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agro_farm/transaction.html"><img src="content://ru.zdevs.zarchiver.external/storage/emulated/0/XXXAVIER%20/Box/food/Agrohub/menu.jpg" id='image_menu'/></a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/deposit.html">Deposit</a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/withdraw+.html">Withdraw</a></li>
                <li><a href="http://localhost:26543/storage/emulated/0/XXXAVIER+/Box/food/Agrohub/send.html">Send</a></li>
            </ul>
        </nav>
        </header>
            <center>
                <h3><label>Enter reciever's number</label></h3>
                <label>
                    256
                <input type="number" name="number_input" id="number_input" value=""  maxlength="9" required/>
                </label><br>
                <h3>Enter amount</h3>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="number" id="amount" required/>
                <br><br>
                <input type="submit" id="Depo" onclick="Teju()"/>
            </center>
        <script>
        var date = newDate().value;
                function Teju() {
                    var no = document.getElementById('number_input').value;
                    var name =document.getElementById('amount').value;
                    if (name != null) {
                        alert("Amount UGX " + name + " successfully sent to " + '0' + no);
        }
    }

        </script>
        </body>
    </html>''')       # rendering the template in HttpResponse 
