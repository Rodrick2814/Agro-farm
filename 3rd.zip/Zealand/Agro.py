#DefaultWsdlHelpGenerator.aspx: 
#
# Author:
#   Rodrick Xavier (Rodrick@xxxavier.com)
#
# (C) 2022 Xxxavier, Inc.  http://www.#xxxavier
print("WELCOME TO AGROMAX")
print("DEPOSIT CASH")
print("WITHDRAW MONEY")
print("SEND MONEY")
def deposit():
    cash = 100000
    amount = int(input("ENTER AMOUNT :"))
    new_balance = cash + amount
    if amount>0:
        print("Amount UGX",amount,"deposited successfully.New balance is:",new_balance)
    else:
        print("ENTER A VALID AMOUNT")
        
def withdraw_cash():
    cash = 100000
    date = datetime.datetime.now()
    amount = int(input("ENTER AMOUNT"))
    if amount>0 and amount<= cash:
        remaining_cash = cash - amount
        print("UGX",amount,"withdrawn successfully on :",date,"Remaining balance is :",remaining_cash)
    else:
        print("Not enough money on your account")
        
def send_money():
    cash = 100000
    date = datetime.datetime.now()
    receiver = int(input("ENTER RECIEVER'S NUMBER"))
    amount = int(input("ENTER AMOUNT"))
    if amount>0 and amount <= cash:
        new_balance = cash - amount
        print("Amount UGX",amount,"sent to",receiver,"on",date,".New balance is :",new_balance)
    else:
        print("Not enough money on your account")
        user = int(input("CHOOSE OPTION"))
if user == 1:
    deposit()
elif user == 2:
    withdraw_cash()
elif user == 3:
    send_money()
else:
    print("Make a valid choice")